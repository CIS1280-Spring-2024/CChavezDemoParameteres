//	ChavezComp1Act2
//  Programer: Colby Chavez
//	Contact: Chavez572@cnm.edu
//	Puropose: Display required text via output for points in class 

#include <iostream>
using namespace std;

int main()
{
    cout << "Colby Chavez \n";
    cout << "ChavezComp1Act2 \n";
    cout << "Program objective: Display required text via output for points in class \n \n";
    cout << "I am currently in a College Algebra Plus class at CNM \n";
    cout << "I took Intermdite Algebra duing the Summer but only got a 77%. So I felt I needed the extra support in math \n  \n";
    cout << "I also workied in software develpment in a non-engineering role for 10 years \n";
    cout << "I know just about everything about making software, but how to write code. \n \n";
    cout << "My favorite thing about programing is that it is literally wizardry. \n";
    cout << "With it you can make anythinng you can imagine from nothing but electrons. \n \ n";
    return 0;
}

