#include <iostream>
using namespace std;
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

// In a comment in  the Functions.h file, describe the return from the EvenOrOdd function and what it means.
//  Function delcration
void WriteHeader();
int EvenOrOdd(int userInput);

#endif