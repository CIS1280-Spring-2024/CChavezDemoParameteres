#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
using namespace std;
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void WriteHeader();
void WriteGoodbye();
void AskForTwoNumbers(int& refNumb1, int& refNumb2);
int FindBigOne(int num1, int num2);

#endif



